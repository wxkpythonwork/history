#!/bin/bash

python3 loglikelihood_online_v0.py $1 $2 $3 $4
