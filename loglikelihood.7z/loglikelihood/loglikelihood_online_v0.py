import os
import sys
import s3fs
import time
import math
import pickle
import logging
import operator
import pandas as pd
from tqdm import tqdm
from dateutil.parser import parse
from collections import defaultdict
from datetime import datetime, timedelta
from itertools import product,combinations
from multiprocessing import Process, Manager

logging.basicConfig(level=logging.INFO,
                    format='%(asctime)s-[%(levelname)s]: %(message)s',
                    datefmt='%Y-%m-%d %H:%M:%S')


def entropy(elements):
    sum = 0
    for element in elements:
        sum += element
    result = 0.0
    for x in elements:
        if x != 0:
            result += x * math.log(float(x)/float(sum))
    return -result

def logLikelihoodRatio(k11, k12, k21, k22):
    #note that we have counts here, not probabilities, and that the entropy is not normalized.
    rowEntropy = entropy([k11,k12])+entropy([k21,k22])
    columnEntropy = entropy([k11,k21])+entropy([k12,k22])
    matrixEntropy = entropy([k11, k12, k21, k22])
    return 2.0 * (-rowEntropy - columnEntropy + matrixEntropy)

def worker_process(l,workers,sku_cookie,sku_candidate,cookie_len,sku_cate_map,sku_online,sim_s,result):
    '''worker function'''
    print(str(workers)+' represent!')
    for k in tqdm(set(l)):
        y = sku_cookie[k]
        sku_set = sku_candidate[k]
        for sub_x,sub_y in sku_cookie.items():
            if sub_x in sku_set:
                k11=len(y&sub_y)
                k12=len(y)-k11
                k21=len(sub_y)-k11
                k22=cookie_len-(k11+k12+k21)
                sim=logLikelihoodRatio(k11,k12,k21,k22)
                sim_s[k][sub_x]=sim
        sorted_x = [i for i in sorted(sim_s[k].items(), key=operator.itemgetter(1), reverse=True) if i[0] in sku_online]
        result[k] = [sku for sku in sorted_x if sku[0]!=k][:100]                                                                                                                                                                                                                                            
#days_id = 16
#data_path = 's3://abc-ailab/individual/getengq/tmp/multi_action/'#'s3://abc-rec/prod/ml/prod/als/multi_action/'
#out_path = '/data/ai-code/loglikelihood/loglikelihood/result_sa_cate_logllh.dat.20200616'
#site_id = 'iosshsa'
days_id = int(sys.argv[1])
data_path_id = sys.argv[2]
out_path = sys.argv[3]
site_cate = sys.argv[4]
        
if '|' in site_cate:
    site_id_list, cate_3 = site_cate.strip().split('|')
    site_id = site_id_list.strip().split(',')[0]
    cate_3_id_list = cate_3.strip().split(',')
else:
    site_id = site_cate.strip().split(',')[0]
    cate_3_id_list = []

s3 = s3fs.S3FileSystem(anon=False)
yesterday = (datetime.now() - timedelta(days=1))
yest_time = '{0}{1:0>2d}{2:0>2d}'.format(yesterday.year, yesterday.month, yesterday.day)

data_path = data_path_id.strip().split(',')[1]
data_common_path = data_path_id.strip().split(',')[0]+'{}_{}.dat'.format(site_id, yest_time)
#data_common_path = 's3://abc-rec/prod/ml/prod/common/shein_goods_onsale_{}.dat'.format(yest_time)
try:
    data_df = pd.read_csv(data_common_path, dtype=str, sep='\t', names=['goods_id','sku_cate_id','cate_name'])
except:
    print('The {} data not update!!!'.format(yest_time))
    exit(1000)
#data_df = data_df[data_df['site_id']==site_id]
cate_online = set(data_df['sku_cate_id'].unique())
sku_online = set(data_df['goods_id'].unique())
print('{} have {} cate and {} skus'.format(yest_time,len(cate_online),len(sku_online)))

cate_num = 0
#cate_3_id_list = ['1727','1766','2332','1991','1889','1767','2058','1924','2333','2040']#sa
#cate_3_id_list = ['1766','2191','1727','1767','1930','2040','2225','1860','2195','2228']#us
for cate_id in cate_3_id_list:
    cate_num += 1
    start_time = time.time()
    session_list, click_data = [], dict()
    sku_cate_map, user_list_map = {}, defaultdict(list)
    
    for m in range(0,days_id):
        n = m + 1
        t_days = (datetime.now() - timedelta(days=n))
        date_time = '{0}{1:0>2d}{2:0>2d}'.format(t_days.year, t_days.month, t_days.day)
        print(date_time, site_id)
        try:
            f = data_path+'{}_{}.dat'.format(site_id, date_time)
            print('start process {} file...'.format(f))
            df = pd.read_csv(f, dtype=str, sep='\t', names=['user_id','member_id',\
                             'goods_id','sku_cate_3_id','sku_cate_id','action_type','log_time'])
            #df = df[df['site_id']==site_id]
            df = df[df['sku_cate_3_id']==cate_id]
            df = df.drop(['member_id','sku_cate_id'], axis=1)
            result = df
        except BaseException as e:
            print('read_csv error')
            continue
        print('make multiple behaviors data done, time cost {0}'.format(str(time.time() - start_time)))
        df = result.sort_values(by=['user_id', 'log_time'], ascending=True)
        for data in tqdm(df.values.tolist()):
            user_id = data[0]
            good_id = data[1]
            cate_id = data[2]
            sku_cate_map[good_id] = cate_id
            user_list_map[user_id].append(good_id)
        if n == days_id:
            session_list = list(user_list_map.values())
            print('all the train data number:',len(session_list))
        print('one day have the train data number:',len(user_list_map))
    
    all_sku = set()
    for i,session in enumerate(session_list):
        for sku in session:
            all_sku.add(sku)
        if len(session)>=5 and len(session)<=100:
            click_data[str(i)] = session
    print('The train data num:',len(click_data))
    print('The total sku number:', len(all_sku))
    
    glb_oi_set=set([x for x,y in click_data.items()])
    cookie_len=len(glb_oi_set)
    sku_cookie=defaultdict(set)
    for k, v in tqdm(click_data.items()):
        for sku in v:
            sku_cookie[sku].add(k)
    
    print('computing the sku and sku common num...')
    time1 = time.time()
    sku_sku_count=defaultdict(dict)
    for k,v in tqdm(click_data.items()):
        for skua, skub in combinations(v, 2): 
            try:
                sku_sku_count[skua][skub] += 1
                sku_sku_count[skub][skua] += 1
            except KeyError:
                sku_sku_count[skua][skub] = sku_sku_count[skub][skua] = 1 
    print('computing the common count time is:',time.time()-time1)
    
    print('Getting the top1000 sku candinate...')
    sku_candidate=defaultdict(set)
    for x,y in tqdm(sku_sku_count.items()):
        top_500=set([ xdata for xdata,ydata in sorted(y.items(),key=lambda x:x[1],reverse=True)][:1000])
        sku_candidate[x]=top_500
    
    import gc
    del click_data, sku_sku_count
    gc.collect()
    
    process_num = 5
    manager = Manager()
    result = manager.dict()
    sim_s = defaultdict(dict)
    all_sku_list = list(sku_cookie.keys())
    
    jobs = []
    for workers in range(process_num):
        if len(all_sku_list)%process_num==0:
            l = all_sku_list[(len(all_sku_list)//process_num)*workers:(len(all_sku_list)//process_num)*(workers+1)]
        else:
            if workers == process_num-1:
                l = all_sku_list[(len(all_sku_list)//process_num)*workers:]
            else:
                l = all_sku_list[(len(all_sku_list)//process_num)*workers:(len(all_sku_list)//process_num)*(workers+1)]
        p = Process(target=worker_process, args=(l,workers,sku_cookie,sku_candidate,cookie_len,sku_cate_map,sku_online,sim_s,result))
        p.start()
        jobs.append(p)
    for res in jobs:
        res.join()
    
    if len(site_id.split(',')) == 1:
        print("Single end single site, such as:iosshus")
        id_i = site_id.split(',')[0]
        fn = out_path
        with open(fn, 'a+', encoding='utf8') as file:
            # header information
            if cate_num == 1:
                head = 'site_uid' + ',' + 'goods_id' + ',' + 'item_list'
                file.write(head + '\n' )
            for k,v in result.items():
                line = id_i+','+k+','
                content = ''
                for i in v:
                    pair = i[0] +':'+str(round(i[1],4))
                    content += pair +'|'
                line += content
                line=line.strip('|')
                file.write(line + '\n')
        print('Completed the {} file!'.format(fn))
    print('the num {} {} cate completed write result!'.format(cate_num,cate_id))
