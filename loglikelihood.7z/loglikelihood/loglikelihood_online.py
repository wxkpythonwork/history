# -*- coding:utf-8 -*-
import os
import sys
import math
import logging
import operator
from tqdm import tqdm
from itertools import product
from collections import  defaultdict
from datetime import datetime, timedelta

logging.basicConfig(level=logging.INFO,
                    format='%(asctime)s-[%(levelname)s]: %(message)s',
                    datefmt='%Y-%m-%d %H:%M:%S')


def entropy(elements):
    sum = 0
    for element in elements:
        sum += element
    result = 0.0
    for x in elements:
        if x != 0:
            result += x * math.log(float(x)/float(sum))
    return -result

def logLikelihoodRatio(k11, k12, k21, k22):
    #note that we have counts here, not probabilities, and that the entropy is not normalized.
    rowEntropy = entropy([k11,k12])+entropy([k21,k22])
    columnEntropy = entropy([k11,k21])+entropy([k12,k22])
    matrixEntropy = entropy([k11, k12, k21, k22])
    return 2.0 * (-rowEntropy - columnEntropy + matrixEntropy)

click_data = {}
days_id = int(sys.argv[1])
data_path = sys.argv[2]  #'iosshus or iosshsa,andshsa'
out_path = sys.argv[3]
site_id = sys.argv[4]

site_country_path = '/data/ml-common/site_country.conf'
site_country_map = {}
for line in open(site_country_path,'r'):
    site_country_map[line.split('\t')[0]]=line.split('\t')[1].split('\n')[0]
    
data_common_path = '/data/ml-model/common'
site_id_list = site_id.split(',')
print(days_id, data_path, out_path, site_id_list)
yesterday = (datetime.now() - timedelta(days=1))
yest_time = '{0}{1:0>2d}{2:0>2d}'.format(yesterday.year, yesterday.month, yesterday.day)

data_df = []
sku_cate_map, cate_sku_map = {}, {}
for site_id0 in site_id_list:
    if os.path.exists("{}/{}_goods_onsale_{}.dat".format(data_common_path, site_id0, yest_time)):
        print("{}_goods_onsale_{}.dat is exists!".format(site_id0, yest_time))
    else:
        print("{}_goods_onsale_{}.dat is not exists!".format(site_id0, yest_time))
        exit(1000)
    for line in open("{}/{}_goods_onsale_{}.dat".format(data_common_path, site_id0, yest_time),"r",encoding='UTF-8'):         
        data_df.append(line)
    print(len(data_df))
    
for val in data_df:
    data0 = str(val.split('\t')[0])
    data1 = [str(val.split('\t')[1]),val.split('\t')[2]]
    data2 = str(val.split('\t')[1])
    sku_cate_map[data0] = data1
    cate_sku_map[data2] = data0
print('{} have {} cate and {} skus'.format(yest_time,len(cate_sku_map),len(sku_cate_map)))

for m in range(0,days_id):
    i = m + 1
    t_days = (datetime.now() - timedelta(days=i))
    date_time = '{0}{1:0>2d}{2:0>2d}'.format(t_days.year, t_days.month, t_days.day)
    print(date_time, site_id_list)

    for site_id0 in site_id_list:
        if os.path.exists("{}/{}_{}.dat".format(data_path, site_id0, date_time)):
            print("{}_{}.dat is exists!".format(site_id0, date_time))
        else:
            print("{}_{}.dat is not exists!".format(site_id0, date_time))
            exit(1000)

        data = []
        for line in open("{}/{}_{}.dat".format(data_path, site_id0, date_time),"r",encoding='UTF-8'):
            data.append(line)
        
        for val in data:
            try:
                new_data0 = val.split('\t')[0]
                new_data1 = val.split('\t')[2]
                click_data[new_data0]=eval(new_data1)
            except:
                continue
        print('The date:{} data length'.format(date_time),len(click_data))

print('获取cookie后的sku与cookie之间的关系')
glb_oi_set=set([x for x,y in click_data.items()])
cookie_len=len(glb_oi_set)
sku_cookie=defaultdict(set)
for k, v in tqdm(click_data.items()):
    for sku in v:
        sku_cookie[sku].add(k)

print('获取sku与sku之间的共现')
sku_sku_count=defaultdict(defaultdict)
for glb_od in tqdm(glb_oi_set):
    for skua, skub in product(click_data[glb_od], click_data[glb_od]):
        if skua == skub:
            continue
        if skua not in sku_sku_count:
            sku_sku_count[skua][skub] = 1
        elif skub not in sku_sku_count[skub]:
            sku_sku_count[skua][skub] = 1
        else:
            sku_sku_count[skua][skub] += 1

print('获取sku的top500相关的sku，用于后续likelihood相似度计算')
sku_candidate=defaultdict(set)
for  x,y in tqdm(sku_sku_count.items()):
    top_500=set([ xdata for xdata,ydata in sorted(y.items(),key=lambda x:x[1],reverse=True)][:300])
    sku_candidate[x]=top_500

print('计算likelihood相似度')
sku_error = 0
sim_s = defaultdict(dict)
result = defaultdict(list)
for x,y in tqdm(sku_cookie.items()):
    try:
        sku_set = sku_candidate[x]
        for sub_x,sub_y in sku_cookie.items():
            if sub_x in sku_set:
                k11=len(y&sub_y)
                k12=len(y)-k11
                k21=len(sub_y)-k11
                k22=cookie_len-(k11+k12+k21)
                sim=logLikelihoodRatio(k11,k12,k21,k22)
                sim_s[x][sub_x]=sim
                sorted_x = [i for i in sorted(sim_s[x].items(), key=operator.itemgetter(1), reverse=True) if i[0] in sku_cate_map]
                result[x] = [sku for sku in sorted_x if sku[0]!=x and sku_cate_map[x]==sku_cate_map[sku[0]]][:100]
    except:
        sku_error += 1
        continue
print('sku error num: ',sku_error)

if len(site_id.split(',')) == 1:
    print("Single end single site, such as:iosshus")
    id_i = site_id.split(',')[0]
    fn = out_path
    with open(fn, 'w', encoding='utf8') as file:
        # header information
        head = 'site_uid' + ',' + 'goods_id' + ',' + 'item_list'
        file.write(head + '\n' )
        for k,v in result.items():
            line = id_i+','+k+','
            content = ''
            for i in v:
                pair = i[0] +':'+str(round(i[1],4))
                content += pair +'|'
            line += content
            line=line.strip('|')
            file.write(line + '\n')
    print('Completed the {} file!'.format(fn))

elif len(site_id.split(',')) == 2:
    print("Single site multi end, such as:iosshsa,andshsa(appshsa)")
    if site_country_map[site_id.split(',')[0]]==site_country_map[site_id.split(',')[0]]:
        site_country = site_country_map[site_id.split(',')[0]]
    else:
        print('site_country error!')
        exit(1001)

    fn = out_path
    with open(fn, 'w', encoding='utf8') as file:
        # header information
        head = 'site_country' + ',' + 'goods_id' + ',' + 'item_list'
        file.write(head + '\n' )
        for k,v in result.items():
            line = site_country+','+k+','
            content = ''
            for i in v:
                pair = i[0] +':'+str(round(i[1],4))
                content += pair +'|'
            line += content
            line=line.strip('|')
            file.write(line + '\n')
    print('Completed the {} file'.format(fn))

else:
    print("Single end multi site, such as:iosshgb,iosshfr,iosshde,iosshes")
    for id_i in site_id.split(','):
        fn = out_path
        with open(fn, 'w', encoding='utf8') as file:
            # header information
            head = 'site_uid' + ',' + 'goods_id' + ',' + 'item_list'
            file.write(head + '\n' )
            for k,v in result.items():
                line = id_i+','+k+','
                content = ''
                for i in v:
                    pair = i[0] +':'+str(round(i[1],4))
                    content += pair +'|'
                line += content
                line=line.strip('|')
                file.write(line + '\n')
        print('Completed the {} file'.format(fn))

